var a = document.querySelector(".dis");
var b = document.querySelector(".hob");

window.onload = addEventListener();

function addEventListener(){

	if (window.addEventListener) {
		var per  = document.getElementById('person').addEventListener('click',display_person,false);
	}		
	if (window.addEventListener) {
		var cl = document.getElementById('close').addEventListener('click',close_per,false);
	}

	function display_person(){
		a.classList.add('bg-active');
		b.classList.add('bg-active');
	}
}


function close_per(){
		// alert("ca");
		a.classList.remove('bg-active');
		b.classList.remove('bg-active');
	}


function close(){
	alert("wd");
}

