<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Placeros extends CI_Controller
{
    /**
     * summary
     */
    function main(){

    	$data['tbl_d'] = $this->b->get_data();
    	$this->load->view('main/index',$data);
    }

    function __construct()
    {
    	parent:: __construct();
    	$this->load->model('data','b');
    }

   
}


?>