<?php  

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * summary
 */
class Data extends CI_Model
{
    /**
     * summary
     */
    public function get_data()
    {
        $table = $this->db->table_exists('placeros');
	    	if ($table) {
	    		$que = $this->db->get('placeros');
	    		if ($que->num_rows() > 0) {
	    			return $que->result();
	    		}
	    		else{
	    			return false;
	    		}
	    	}
	    	else {
	    		return false;
	    	}
    }
}

?>