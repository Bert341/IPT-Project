<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link href="https://fonts.googleapis.com/css2?family=Nerko+One&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<title><?php 

		if ($tbl_d) {
			foreach ($tbl_d as $value) {
			    echo $value->fname." ".$value->lname;
			}
		}

	?></title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>

<!-- main -->
	<main>
		<!-- back color -->
		<div class="color">
			<!-- flex -->
			<div class="head">
				<a href="<?php echo base_url('Placeros/main') ?>" title="Bert"><span><?php 

		if ($tbl_d) {
			foreach ($tbl_d as $value) {
			    echo $value->fname." ".$value->lname;
			}
		}

	?></span></a>
				<div class="list">
					<ul>
						<li><a id="person">Personal</a></li>
						<li><a>Hobby/skills</a></li>
						<!-- <li><span>Personal</span></li> -->
					</ul>
				</div>
			</div>
			<!-- end of flex -->


			<!-- line -->

			<div class="box">
				<div class="box_draw">
					
				</div>
			</div>
			<!-- end of line -->

			<!-- person -->
			<div class="dis">
				<div class="form">
					<div class="text">
						<ul>
							<li><span>Name: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->fname." ".$value->lname;
								}
							}
							?></span></li>
							<li><span>Address: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->address;
								}
							}
							?></span></li>
							<li><span>Age: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->age;
								}
							}
							?></span></li>
							<li><span>Birthdate: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->birthdate;
							    }
							}
							?></span></li>
							<li><span>Gender: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->gender;
								}
							}
							?></span></li>
							<li><span>Email: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->email;
								}
							}
							?></span></li>
							<li><span>Nationality: <?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->nationality;
								}
							}
							?></span></li>
						</ul>
					</div>
					<span id="close" ><img src="<?php echo base_url();?>assets/svg/times-solid.svg" alt="close" width="30" height="30" title="Close" onclick="close();"></span>
				</div>
			</div>
			<!-- end of person -->


			<!-- hobby -->
			<div class="hob">
				<div class="form">
					<div class="text">
						<center><h3>Skills/Hobby</h3></center>
						<ul>
							<li><span>
							<?php 
							if ($tbl_d) {
								foreach ($tbl_d as $value) {
							    	echo $value->hobby;
								}
							}
							?>
								
							</span></li>
						</ul>
					</div>
				</div>
			</div>
			<!-- end of hobby -->

		</div>
		<!-- end of back color -->
	</main>
	<!-- end of main -->

	<script type="text/javascript" src="<?php echo base_url('assets/js/function.js'); ?>"></script>
	
</body>
</html>